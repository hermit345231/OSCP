import re

myfile = "result.txt"

with open(myfile, "r+") as f:
    data = f.read()
    f.seek(0)
    f.write(re.sub(r"\[.+?m", r"", data))
    f.truncate()
