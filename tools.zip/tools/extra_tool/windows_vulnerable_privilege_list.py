# Scipt per trovare permissi utente vulnerabili

prev = open('whoami.txt', 'r').read()
listA = ['SeAssignPrimaryToken', 'SeAudit, SeBackup, SeChangeNotify', 'SeCreateGlobal', 'SeCreatePagefile', 'SeCreatePermanent', 'SeCreateSymbolicLink', 'SeCreateToken', 'SeDebug', 'SeDelegateSession-UserImpersonate', 'SeEnableDelegation', 'SeImpersonate', 'SeIncreaseBasePriority', 'SeIncreaseQuota', 'SeIncreaseWorkingSet', 'SeLoadDriver', 'SeLockMemory', 'SeMachineAccount', 'SeManageVolume', 'SeProfileSingleProcess', 'SeRelabel', 'SeRemoteShutdown', 'SeReserveProcessor', 'SeRestore', 'SeSecurity', 'SeShutdown', 'SeSyncAgent', 'SeSystemEnvironment', 'SeSystemProfile', 'SeSystemtime', 'SeTakeOwnership', 'SeTcb', 'SeTimeZone', 'SeTrustedCredManAccess', 'SeUndock', 'SeUnsolicitedInput']
res = [ele for ele in listA if(ele in prev)]
print("Vulnerable privileges in the system: "+str(res))

